<?php

class Email {
	
	// DECLARING REQUIRED PROPERTIES
	public $from_email;
	public $from_name;
	public $smtp_host;
	public $smtp_username;
	public $smtp_password;
	public $smtp_port;
	public $smtp_timeout;
	public $email_to_id ;
	public $email_to_name;
	public $email_subject;
	public $email_body;
	public $default_smtp ;
	public $admin_email ;
	public $admin_name ;
	public $status;
	

	// DECLARING FUNCTION CONSTRUCTOR TO GET THE $email_to & $email_body EVERYTIME THE CLASS IS CALLED
	public function __construct($registry) {
		$this->config = $registry->get('config');
		$this->customer = $registry->get('customer');
		$this->session = $registry->get('session');
		$this->db = $registry->get('db');
		
		// GETTING THE DEFAULT SMTP
		$sql1 = "SELECT * FROM opl_default_smtp WHERE id = 1 ";
		$query1 = $this->db->query($sql1);
		$row = $query1->rows;
		
		$this->default_smtp    = $row[0]['active_smtp'];

		// GETTING THE DEFAULT SMTP DETAILS
		$sql2 = "SELECT * FROM opl_email_smtp WHERE smtp_id = $this->default_smtp";
        $query2 = $this->db->query($sql2);
        $smtp_output =  $query2->rows;
		
		$this->smtp_host       = $smtp_output[0]['smtp_hostname'];
		$this->smtp_username   = $smtp_output[0]['smtp_username'];
		$this->smtp_password   = $smtp_output[0]['smtp_password'];
		$this->smtp_port       = intval($smtp_output[0]['smtp_port']);
		$this->smtp_timeout    = $smtp_output[0]['smtp_timeout'];

		// GETTING SET FROM EMAIL AND FROM NAME
        $query3 = $this->db->query("SELECT * FROM opl_email_setting ORDER BY ID DESC LIMIT 1");
		$settings_output = $query3->rows;
		
		$this->from_email     = $settings_output[0]['from_email'];
		$this->from_name      = $settings_output[0]['from_name'];
		$this->admin_email    = $settings_output[0]['admin_email'];
		$this->admin_name     = $_SERVER['SERVER_NAME'] ;
	}
	
	// METHOD TO TRIGGER SENDING AN EMAIL
    public function sendemail(){
		require_once (DIR_SYSTEM . 'library/phpmailer/src/Exception.php');
		require_once (DIR_SYSTEM . 'library/phpmailer/src/PHPMailer.php');
		require_once (DIR_SYSTEM . 'library/phpmailer/src/SMTP.php');
		

		$mail = new PHPMailer\PHPMailer\PHPMailer;
		$mail->isSMTP(); 
		$mail->SMTPDebug  = 1;                               // 0 = off (for production use),  1 = client messages, 2 = client and server messages        
		$mail->Debugoutput = function($str, $level){
			file_put_contents(
				'system/library/phpmailer/email.log',
				date('Y-m-d H:i:s') . "\t" . $str,
				FILE_APPEND | LOCK_EX
			  );
		};
		$mail->Host       = $this->smtp_host ;               // USE $mail->Host = gethostbyname('smtp.gmail.com'); IF YOUR NETWORK DOES NOT SUPPORT SMTP OVER IPV6
		$mail->Port       = $this->smtp_port ;               // TLS ONLY
		$mail->SMTPSecure = 'tls';                           // SSL IS DEPRECATED
		$mail->SMTPAuth   = true;
		$mail->Username   = $this->smtp_username;
		$mail->Password   = $this->smtp_password;
		$mail->setFrom($this->from_email, $this->from_name);
		$mail->addAddress($this->email_to_id, $this->email_to_name);
		$mail->Subject    = $this->email_subject;
		$mail->isHTML(true);
		$mail->Body       = html_entity_decode($this->email_body);		
		//$mail->msgHTML("<h3>Testing the smtp</h3> <br> <br> <P>Lets See How It Looks</p>"); //$mail->msgHTML(file_get_contents('contents.html'), __DIR__); //Read an HTML message body from an external file, convert referenced images to embedded,
		$mail->AltBody = 'HTML messaging not supported';
		//$mail->addAttachment('images/phpmailer_mini.png');  //Attach an image file

		if(!$mail->send()){
		$this->status = "SUCCESS : Email Sent Successfully";
		}else{
			$this->status = "FAILED : Email not Sent, Check Logs for more info.";
		}

	}

}
?>
