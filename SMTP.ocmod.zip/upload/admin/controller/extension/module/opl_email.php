<?php
class ControllerExtensionModuleOplEmail extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/opl_email');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model('extension/opl_email');
		$this->model_extension_opl_email->createdatabase();		

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_opl_email', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', false));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], false)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', false)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/opl_email', 'user_token=' . $this->session->data['user_token'], false)
		);

		$data['action'] = $this->url->link('extension/module/opl_email', 'user_token=' . $this->session->data['user_token'], false);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', false);

		if (isset($this->request->post['module_opl_email_status'])) {
			$data['module_opl_email_status'] = $this->request->post['module_opl_email_status'];
		} else {
			$data['module_opl_email_status'] = $this->config->get('module_opl_email_status');
		}
		print_r($this->config->get('module_opl_emaily_status'));
		
		// SETTING THE DATA ARRAY
		$data['token'] = $this->session->data['user_token'];
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/opl_email', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/opl_email')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	// CUSTOM CODE STARTS HERE -------------------------------------------------------------------

	public function home(){
		// DECLARING THE REQUIRED FILES		
		$this->load->language('extension/module/opl_email');
		$this->document->addStyle('view/stylesheet/opl_email.css');
		$this->load->model('setting/setting');
		$this->load->model('extension/opl_email');
		

		// SETTIGN THE BREADCRUMBS
		$data['breadcrumbs']   = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], false)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', false)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/opl_email/home', 'user_token=' . $this->session->data['user_token'], false)
		);

		// CHECKING IF THE EXTENSION IS LISCENSED OR NOT		
		$output = $this->model_extension_opl_email->crud2();
		if(!empty($output)){
			$ext_key = $output[0]['ext_key'];
			$ext_id = 39174;
			$sender = $_SERVER['SERVER_NAME'];
			$url = "http://license.opencartlabs.net/rest/key_api.php?ext_id=$ext_id&ext_key=$ext_key&sender=$sender";
			$client = curl_init($url);
			curl_setopt($client,CURLOPT_RETURNTRANSFER,false);
			$license_response = intval(curl_exec($client));
			$data['license_response']   = $license_response;
		} else {
			$data['license_response']   = 2;
		}
				
		// GEETING THE LAST UPDATED SETTINGS RECORDS
		$fetched_settings = $this->model_extension_opl_email->fetchSettings();
		if(!empty($fetched_settings)){
			foreach($fetched_settings as $key => $value){
				$fetched_from_email    = $value['from_email'];
				$fetched_from_name     = $value['from_name'];
				$fetched_admin_email   = $value['admin_email'];
			}
			$data['from_email']   = $fetched_from_email;
			$data['from_name']    = $fetched_from_name;
			$data['admin_email']  = $fetched_admin_email;
		} else {
			$data['from_email']   = "";
			$data['from_name']    = "";
			$data['admin_email']  = "";
		}

		// GETTING THE DEFAULT SMTP AS OUTPUT
		$row = $this->model_extension_opl_email->fetchDefault();
		if(!empty($row)){
			$data['def_smtp'] = intval($row[0]['active_smtp']);		
		} else {
			$data['def_smtp'] = 0 ;
		}
		
		// SETTING THE DATA ARRAY
		$data['token']       = $this->session->data['user_token'];
		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');
		$data['smtp']        = $this->fetch_smtp();
		$data['email_logs']  = $this->fetch_emaillogs();
		$data['support']     = $this->load->view('extension/module/opl_email/support');
		$data['liscense']    = $this->fetch_liscense();				
		
		// RENDERING THE OUTPUT 
		$view = $this->load->view('extension/module/opl_email/home', $data);
		$this->response->setOutput($view);

		return $data;
	}

	public function saveSetting(){
		// LOADING REQUIRED FILES
		$this->load->model('setting/setting');
		$this->load->model('extension/opl_email');
		$token = $this->session->data['user_token'];

		// CATCHING THE SETTINGS POST REQUEST
		if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->request->post['submit_email_name_setting']){
			$from_email        = $this->request->post['fromemail'];
			$from_name         = $this->request->post['fromname'];
			$admin_email       = $this->request->post['adminemail'];
			$default_smtp      = $this->request->post['default_smtp'];

			// UPDATING SETTINGS IN DB
			$this->model_extension_opl_email->updateSettings($from_email, $from_name, $admin_email);

			// SETTING THE DEFAULT SMTP IN DB
			if(!empty($this->model_extension_opl_email->fetchDefault())){
				$this->model_extension_opl_email->setDefault($default_smtp);
			} else {
				$this->model_extension_opl_email->createDefault($default_smtp);
			}
		
			// REDIRECTING THE USER BACK TO HOME
			header("Location:index.php?route=extension/module/opl_email/home&user_token=$token");				
		}		
	}

	public function saveSmtp(){
		// LOAD REQURIED FILES
		$this->load->model('setting/setting');
		$this->load->model('extension/opl_email');
		$token = $this->session->data['user_token'];

		// CATCHING THE SETTINGS POST REQUEST
		if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->request->post['smtp_id']){
				$smtp_id                   = $this->request->post['smtp_id'];
			if(isset($this->request->post['smtp_host'])){
				$smtp_host                 = $this->request->post['smtp_host'];
			}
			if(isset($this->request->post['smtp_username'])){
				$smtp_username             = $this->request->post['smtp_username'];
			}
			
			if(isset($this->request->post['smtp_password'])){
				$smtp_password             = $this->request->post['smtp_password'];
			}
			
			if(isset($this->request->post['smtp_port'])){
				$smtp_port                 = $this->request->post['smtp_port'];
			}
			
			if(isset($this->request->post['smtp_timeout'])){
				$smtp_timeout              = $this->request->post['smtp_timeout'];
			}

			var_dump($this->request->post);

			// UPDATING SETTINGS IN DB
			switch ($smtp_id) {
				case 1:
					$this->model_extension_opl_email->updateSmtp1($smtp_username, $smtp_password);
					break;
				case 2:
					$this->model_extension_opl_email->updateSmtp2($smtp_host, $smtp_username, $smtp_password);
					break;
				case 3:
					$this->model_extension_opl_email->updateSmtp3($smtp_password);
					break;
				case 4:
					$this->model_extension_opl_email->updateSmtp4($smtp_username, $smtp_password);
					break;
				case 5:
					$this->model_extension_opl_email->updateSmtp5($smtp_username, $smtp_password);
					break;
				case 6:
					$this->model_extension_opl_email->updateSmtp6($smtp_username, $smtp_password);

					break;
				case 7:
					$this->model_extension_opl_email->updateSmtp7($smtp_host, $smtp_username, $smtp_password, $smtp_port, $smtp_timeout);
					break;
			}			 				

			// REDIRECTING THE USER BACK TO HOME
			header("Location:index.php?route=extension/module/opl_email/home&user_token=$token");
		}		
	}

	public function savelogs(){

	}

	public function fetch_smtp(){
		// LOADING REQURIED FILES
		$this->load->language('extension/module/opl_email');
		$this->document->addStyle('view/stylesheet/opl_email.css');
		$this->load->model('setting/setting');
		$this->load->model('extension/opl_email');

		// GETTING THE SAVED SMTP DETAILS FROM DATABASE 
		$fetched_smtp_records = $this->model_extension_opl_email->fetchSmtp();

		//var_dump($fetched_smtp_records);
		$smtp_1 = array();
		$smtp_2 = array();
		$smtp_3 = array();
		$smtp_4 = array();
		$smtp_5 = array();
		$smtp_6 = array();
		$smtp_7 = array();

		foreach($fetched_smtp_records as $key => $value){
			if($key == 0){
				$smtp_1 = $value;
			}
			if($key == 1){
				$smtp_2 = $value;
			}
			if($key == 2){
				$smtp_3 = $value;
			}
			if($key == 3){
				$smtp_4 = $value;
			}
			if($key == 4){
				$smtp_5 = $value;
			}
			if($key == 5){
				$smtp_6 = $value;
			}
			if($key == 6){
				$smtp_7 = $value;
			}
		}

		$data['smtp1']       = $smtp_1;
		$data['smtp2']       = $smtp_2;
		$data['smtp3']       = $smtp_3;
		$data['smtp4']       = $smtp_4;
		$data['smtp5']       = $smtp_5;
		$data['smtp6']       = $smtp_6;
		$data['smtp7']       = $smtp_7;
		$data['token']       = $this->session->data['user_token'];

		// INSERTING THE DATA IN HTML FILE AND RETURNING THE WHOLE FILE
		return $this->load->view('extension/module/opl_email/smtp', $data);
	}

	public function fetch_emaillogs(){
	// LOADING THE REQUIRED FILES
	$this->load->model('extension/opl_email');
	// OUTPUT DATA
	if(file_exists(DIR_SYSTEM . 'library/phpmailer/email.log')){
		$data['email_log'] = file_get_contents(DIR_SYSTEM . 'library/phpmailer/email.log');
		// INSERTING THE DATA IN HTML FILE AND RETURNING THE WHOLE FILE
		return $this->load->view('extension/module/opl_email/logs', $data);
	    } else {
			return $this->load->view('extension/module/opl_email/logs');
		}
	}

	public function savelicense(){
		$token = $this->session->data['user_token'];
		$this->load->model('extension/opl_email');

		if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->request->post['savelicense']){
			$ext_key = $this->request->post['licensekey'];
			$key_exists = $this->model_extension_opl_email->crudR();

			if(!empty($key_exists)){
				$this->model_extension_opl_email->crud1($ext_key);	
			} else {
				$this->model_extension_opl_email->crudC($ext_key);
			}			
			
			header("Location:index.php?route=extension/module/opl_email/home&user_token=$token");
		}
	}

	public function fetch_liscense(){
	// LOADING THE REQUIRED FILES
	$this->load->model('extension/opl_email');
	$token = $this->session->data['user_token'];
	$data['token'] = $token;
	
	// GETTING THE LISCENSE KEY FROM DB
	$out_data = $this->model_extension_opl_email->crud2();
	if(!empty($out_data)){
		$key_value = $out_data[0]['ext_key'];
	} else {
		$key_value = "";
	}
			// CHECKING IF THE EXTENSION IS LISCENSED OR NOT		
			$output = $this->model_extension_opl_email->crud2();
			if(!empty($output)){
				$ext_key = $output[0]['ext_key'];
				$ext_id = 39174;
				$sender = $_SERVER['SERVER_NAME'];
				$url = "http://license.opencartlabs.net/rest/key_api.php?ext_id=$ext_id&ext_key=$ext_key&sender=$sender";
				$client = curl_init($url);
				curl_setopt($client,CURLOPT_RETURNTRANSFER,false);
				$license_response = intval(curl_exec($client));
				$data['license_response']   = $license_response;
			} else {
				$data['license_response']   = 2;
			}
	// OUTPUT DATA
	$data['license'] = $key_value;
	// INSERTING THE DATA IN HTML FILE AND RETURNING THE WHOLE FILE
	return $this->load->view('extension/module/opl_email/liscense', $data);
	}

	

	
} //CLASS ENDS HERE


