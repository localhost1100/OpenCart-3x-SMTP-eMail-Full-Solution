<?php
// Heading
$_['heading_title']    = 'Email & SMTP ';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Email module!';
$_['text_edit']        = 'Edit Email & SMTP Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fromemail']  = 'Enter from Email';
$_['entry_fromname']   = 'Enter from Name';
$_['gsuite_name']      = 'Gsuite';
$_['aws_ses_name']     = 'AWS SES';
$_['sendgrid_name']     = 'sendgrid';
$_['sendinblue_name']     = 'Sendinblue';
$_['pepipost_name']     = 'Pepipost';
$_['mailgun_name']     = 'Mailgun';
$_['custom_name']     = 'Custom SMTP';

// FORM TEXT
$_['smtp_host']        = 'SMTP Hostname';
$_['smtp_username']    = 'SMTP Username';
$_['smtp_password']    = 'SMTP Password';
$_['smtp_port']        = 'SMTP Port';
$_['smtp_timeout']     = 'SMTP Timeout';

// PLACEHOLDERS
$_['host_ph']          = 'Enter the Host Name Provided';
$_['username_ph']      = 'Enter your Username';
$_['password_ph']      = 'Enter your smtp password';
$_['port_ph']          = 'Desired SMTP Port';
$_['timeout_ph']       = 'SMTP TImeout Value';



// Error
$_['error_permission'] = 'First Install & Enable it from Extensions/Modules';