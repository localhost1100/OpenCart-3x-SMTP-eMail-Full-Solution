<?php
class ModelExtensionOplEmail extends Model{
    //public $table = "opl_email_setting";

    public function createdatabase(){
        // CREATING THE DEFAULT SMTP TABLE & INSERTING DUMMY TEXT
            $sql1 = "CREATE TABLE IF NOT EXISTS `opl_default_smtp` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `active_smtp` int(11) NOT NULL,
                PRIMARY KEY (`id`)
              ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4";    
            $this->db->query($sql1);

        // CREATING THE LICENSE TABLE
        $sql3 = "CREATE TABLE IF NOT EXISTS `opl_email_key` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `ext_key` varchar(255) NOT NULL,
            PRIMARY KEY (`id`)
          ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4";
        $this->db->query($sql3);

        // CREATING THE EMAIL SETTINGS TABLE
        $sql4 = "CREATE TABLE IF NOT EXISTS `opl_email_setting` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `from_email` varchar(255) NOT NULL,
            `from_name` varchar(255) NOT NULL,
            `admin_email` varchar(255) NOT NULL,
            PRIMARY KEY (`id`)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        $this->db->query($sql4);

        // CREATING EMAIL SMTP RECORDS TABLE
        $sql5 = "CREATE TABLE IF NOT EXISTS `opl_email_smtp` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `smtp_id` int(11) NOT NULL,
            `smtp_name` varchar(255) NOT NULL,
            `smtp_hostname` varchar(255) NOT NULL,
            `smtp_username` varchar(255) NOT NULL,
            `smtp_password` varchar(255) NOT NULL,
            `smtp_port` int(11) NOT NULL,
            `smtp_timeout` int(11) NOT NULL,
            `smtp_active_status` int(11) NOT NULL,
            `smtp_last_updated` date NOT NULL,
            PRIMARY KEY (`id`)
          ) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4";
        $this->db->query($sql5);

        $sql7 = "SELECT * FROM opl_email_smtp ";
        $query = $this->db->query($sql7);
        $output = $query->rows;
        
        // ENTERING THE DEFAULT DATA OF SMTP RECORDS TABLE
        if(empty($output)){
            $sql6 = "INSERT INTO `opl_email_smtp` (`id`, `smtp_id`, `smtp_name`, `smtp_hostname`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_timeout`, `smtp_active_status`, `smtp_last_updated`) VALUES
            (1, 1, 'gsuite', 'smtp.gmail.com', '', '', 587, 60, 1, '0000-00-00'),
            (3, 2, 'aws_ses', '', '', '', 587, 60, 0, '0000-00-00'),
            (4, 3, 'sendgrid', 'smtp.sendgrid.net', 'apikey', '', 587, 60, 0, '0000-00-00'),
            (5, 4, 'sendinblue', 'smtp-relay.sendinblue.com', '', '', 587, 60, 0, '0000-00-00'),
            (8, 5, 'pepipost', 'smtp.pepipost.com', '', '', 587, 60, 0, '0000-00-00'),
            (9, 6, 'mailgun', 'smtp.mailgun.org', '', '', 587, 60, 0, '0000-00-00'),
            (12, 7, 'custom', '', '', '', 587, 60, 0, '0000-00-00')";
            $this->db->query($sql6);
        }

    }

    public function updateSettings($from_email, $from_name, $admin_email){
        $sql = "INSERT into opl_email_setting (from_email, from_name, admin_email) VALUES ('$from_email', '$from_name', '$admin_email')";
        $query = $this->db->query($sql);
    }
    
    public function fetchSettings(){
        $sql = "SELECT * FROM opl_email_setting ORDER BY ID DESC LIMIT 1";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function updateSmtp1($smtp_username, $smtp_password){
        $sql = "UPDATE opl_email_smtp SET        
        smtp_username      = '$smtp_username',
        smtp_password      = '$smtp_password',
        smtp_last_updated  = date('Y:m:d') WHERE smtp_id = 1" ;

        $query = $this->db->query($sql);                
    }

    public function updateSmtp2($smtp_host, $smtp_username, $smtp_password){
        $sql = "UPDATE opl_email_smtp SET 
        smtp_hostname      = '$smtp_host', 
        smtp_username      = '$smtp_username',
        smtp_password      = '$smtp_password',       
        smtp_last_updated  = date('Y:m:d') WHERE smtp_id = 2" ;

        $query = $this->db->query($sql);                
    }

    public function updateSmtp3($smtp_password){
        $sql = "UPDATE opl_email_smtp SET 
        smtp_password      = '$smtp_password',
        smtp_last_updated  = date('Y:m:d') WHERE smtp_id = 3" ;

        $query = $this->db->query($sql);                
    }

    public function updateSmtp4($smtp_username, $smtp_password){
        $sql = "UPDATE opl_email_smtp SET 
        smtp_username      = '$smtp_username',
        smtp_password      = '$smtp_password',
        smtp_last_updated  = date('Y:m:d') WHERE smtp_id = 4" ;

        $query = $this->db->query($sql);                
    }

    public function updateSmtp5($smtp_username, $smtp_password){
        $sql = "UPDATE opl_email_smtp SET 
        smtp_username      = '$smtp_username',
        smtp_password      = '$smtp_password',
        smtp_last_updated  = date('Y:m:d') WHERE smtp_id = 5" ;

        $query = $this->db->query($sql);                
    }

    public function updateSmtp6($smtp_username, $smtp_password){
        $sql = "UPDATE opl_email_smtp SET 
        smtp_username      = '$smtp_username',
        smtp_password      = '$smtp_password',
        smtp_last_updated  = date('Y:m:d') WHERE smtp_id = 6" ;

        $query = $this->db->query($sql);                
    }

    public function updateSmtp7($smtp_host, $smtp_username, $smtp_password, $smtp_port, $smtp_timeout){
        $sql = "UPDATE opl_email_smtp SET 
        smtp_hostname      = '$smtp_host', 
        smtp_username      = '$smtp_username',
        smtp_password      = '$smtp_password',
        smtp_timeout       = '$smtp_timeout',
        smtp_port          = '$smtp_port',
        smtp_last_updated  = date('Y:m:d') WHERE smtp_id = 7" ;

        $query = $this->db->query($sql);                
    }

    public function fetchSmtp(){
        $sql = "SELECT * FROM opl_email_smtp";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function fetchSmtpByid($id){
        $sql = "SELECT * FROM opl_email_smtp WHERE smtp_id = $id";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function checkDefault(){
        $sql = "SELECT * FROM opl_default_smtp WHERE id = 1 ";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function createDefault($smtp_id){
        $sql = "INSERT INTO opl_default_smtp (id, active_smtp) VALUES ('1' , '$smtp_id')";
        $query = $this->db->query($sql);
    }

    public function setDefault($smtp_id){
        $sql = "UPDATE opl_default_smtp SET active_smtp = '$smtp_id' WHERE id = 1";
        $query = $this->db->query($sql);
    }

    public function fetchDefault(){
        $sql = "SELECT * FROM opl_default_smtp WHERE id = 1 ";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    // MEHTOD TO INPUT KEY
    public function crudR(){
        $sql = "SELECT * FROM opl_email_key WHERE id = 1 ";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function crudC($ext_key){
        $sql = "INSERT INTO opl_email_key (id , ext_key) VALUES ('1' , '$ext_key') ";
        $query = $this->db->query($sql);
    }

    // MEHTOD TO INPUT KEY
    public function crud1($ext_key){
        $sql = "UPDATE opl_email_key SET ext_key = '$ext_key' WHERE id = 1 ";
        $query = $this->db->query($sql);
    }    
    
    // METHOD TO GET KEY
    public function crud2(){
        $sql = "SELECT * FROM opl_email_key WHERE id = 1 ";
        $query = $this->db->query($sql);
        return $query->rows;
    }


}

?>